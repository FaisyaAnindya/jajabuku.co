<?php
// include database connection file
include_once("connect.php");
 
// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{	
    $isbn=$_POST['isbn'];
    $judul=$_POST['judul'];
    $cover=$_POST['cover'];
    $tahun=$_POST['tahun'];
    $penerbit=$_POST['penerbit'];
    $nisn=$_POST['nisn'];

        
    // update user data
    $result = mysqli_query($conn, "UPDATE pinjam SET isbn='$isbn',judul='$judul',cover='$cover',tahun='$tahun',penerbit='$penerbit',nisn='$nisn' WHERE isbn=$isbn");
    
    // Redirect to homepage to display updated user in list
    header("Location: index.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$isbn = $_GET['isbn'];
 
// Fetech user data based on id
$result = mysqli_query($conn, "SELECT * FROM pinjam WHERE isbn=$isbn");
 
while($user_data = mysqli_fetch_array($result))
{
    $isbn = $user_data['isbn'];
    $judul = $user_data['judul'];
    $cover=$user_data['cover'];
    $tahun = $user_data['tahun'];
    $penerbit = $user_data['penerbit'];
    $nisn = $user_data['nisn'];

}
?>
<html>
<head>	
    <title>Edit Data Buku</title>
</head>
 
<body>
    <a href="index.php">Home</a>
    <br/><br/>
    
    <form name="update_user" method="post" action="edit.php">
        <table border="0">
            <tr> 
                <td>ISBN</td>
                <td><input type="text" name="isbn" value=<?php echo $isbn;?>></td>
            </tr>
            <tr> 
                <td>Judul</td>
                <td><input type="text" name="judul" value=<?php echo $judul;?>></td>
            </tr>
            <tr> 
                <td>Cover</td>
                <td><input type="text" name="cover" value=<?php echo $tahun;?>></td>
            </tr>
            <tr> 
                <td>Tahun Terbit</td>
                <td><input type="text" name="tahun" value=<?php echo $tahun;?>></td>
            </tr>
            <tr> 
                <td>Penerbit</td>
                <td><input type="text" name="penerbit" value=<?php echo $penerbit;?>></td>
            </tr>
            <tr> 
                <td>NISN Peminjaman</td>
                <td><input type="text" name="nisn" value=<?php echo $nisn;?>></td>
            </tr>


            <tr>
                <td><input type="hidden" name="isbn" value=<?php echo $_GET['isbn'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>